"""Planner Agent: two-stage planning.

Stage 1 plans analysis dimensions and evidence needs before Evidence/Analysis.
Stage 2 freezes the final report structure after actual Facts/Inferences exist.
This keeps content structure driven by evidence while templates control
presentation unless explicitly marked as hard structure.
"""

import json

from app.agents.base import BaseAgent
from app.db import connect
from app.models import ReportPlan

_SYSTEM = """你是情报报告分析规划师。根据用户主题、材料摘要与机构风格,只制定分析问题与证据提取方向,不要冻结最终报告章节。
严格输出 JSON,不要任何解释:
{
  "title": "报告标题",
  "objective": "报告目的(解决什么问题、支撑什么决策)",
  "audience": "报告受众",
  "report_type": "报告类型(与机构风格变体对应)",
  "core_question": "报告要回答的核心问题(一句话)",
  "core_judgment": "报告的核心判断/主线结论(一句话)",
  "narrative_logic": "初步分析假设:后续应重点验证哪些关系,可被 Evidence/Analysis 推翻,不要写成最终目录",
  "report_budget": {
    "target_words": 全文目标字数,
    "soft_max_words": 建议最大字数,
    "hard_max_words": 绝对最大字数,
    "summary_budget": 摘要字数预算
  },
  "dimensions": ["优先分析维度1", "优先分析维度2", ...],
  "required_facts": ["证据提取应优先寻找的信息类别"]
}
要求:
1. 只规划 Evidence/Analysis 需要回答的问题和事实类别;不要输出 chapters,不要沿用模板目录
2. 模板主要用于格式、标题层级、编号和版式;除非模板策略明确 HARD_STRUCTURE,不得把模板目录当成最终报告目录
3. dimensions/required_facts 只是优先检索与重点发现方向,不是事实边界;Evidence 必须允许材料中出现的高价值新事实进入
4. 初步分析假设不是最终叙事逻辑,后续 Final Planner 不需要继承,应以真实 Facts/Inferences 为准
5. 规模预算依据:用户明确字数要求(如有)、报告类型档位
   (简要约2000-4000字/标准约5000-10000字/深度约10000-20000字)、材料信息量、章节数与重要性。
6. 最终报告结构将在 Evidence + Analysis 后另行生成,届时由真实 Fact/Inference 和核心结论决定。"""

_FINAL_SYSTEM = """你是情报报告结构总规划师。现在 Evidence 与 Analysis 已完成,请基于真实事实、推断、用户目标和模板策略生成最终 ReportPlan。
严格输出 JSON,不要任何解释:
{
  "title": "报告标题",
  "objective": "报告目的",
  "audience": "报告受众",
  "report_type": "报告类型",
  "core_question": "报告要回答的核心问题",
  "core_judgment": "报告核心判断/主线结论",
  "narrative_logic": "最终叙事逻辑:章节如何递进",
  "chapters": [
    {
      "title": "章节标题",
      "questions": ["本章要回答的问题"],
      "judgment": "本章核心判断/写作目的",
      "relation_to_prev": "与上一章关系",
      "required_facts": ["本章需要覆盖的事实主题"],
      "required_inferences": ["本章需要覆盖的分析判断"],
      "primary_fact_ids": [1, 2],
      "primary_inference_ids": [3],
      "subsections": [
        {
          "title": "二级小标题",
          "purpose": "该小节要解决的问题",
          "primary_fact_ids": [1],
          "primary_inference_ids": [3],
          "detail_level": "expand/brief/reference",
          "target_words": 小节目标字数
        }
      ],
      "exclude": ["避免重复展开的内容"],
      "next_bridge": "承接下一章的逻辑",
      "target_words": 章节目标字数,
      "importance": "high/medium/low",
      "evidence_density": "high/medium/low"
    }
  ]
}
要求:
1. 内容决定结构:章节必须围绕已抽取 Facts/Inferences 和核心结论组织,不得机械沿用模板目录
2. 模板结构类型:
   FORMAT_ONLY: 只控制字体、标题层级、编号、版式和导出呈现
   SOFT_STRUCTURE: 目录只作参考,可借鉴但不得压过材料逻辑
   HARD_STRUCTURE: 只有用户或模板明确要求时才严格遵守
3. 除 HARD_STRUCTURE 外,不要把模板示例目录当成最终目录;模板主要决定呈现,不决定内容逻辑
4. 章节应形成递进关系,不是事实清单分类;常规报告通常 2-6 章,但由证据容量和用户要求决定
5. 小标题也必须由内容需要决定:只有当本章内部确实存在多个相对独立的话题层次时才规划 subsections;小标题不是装饰,不得把一句正文改成标题
6. 初步分析主线只是假设与关注方向;如果 Facts/Inferences 指向不同逻辑,必须调整,不得为继承早期规划而牺牲内容合理性
7. 每个重要事实原则上只在最合适章节完整展开一次,其他章节只做必要承接
8. 证据不足的主题不得硬设独立章节或小节凑结构,应合并为边界、风险或待补充说明。"""


class PlannerAgent(BaseAgent):
    name = "planner"
    role = _SYSTEM

    def plan(self, context_block: str, user_requirements: str = "") -> ReportPlan:
        """Create an analysis plan before evidence extraction."""
        payload = self.generate_json(f"{context_block}\n\n请输出分析规划 JSON。")
        plan = ReportPlan(
            title=str(payload.get("title", "")),
            objective=str(payload.get("objective", "")),
            audience=str(payload.get("audience", "")),
            report_type=str(payload.get("report_type", "")),
            core_question=str(payload.get("core_question", "")),
            core_judgment=str(payload.get("core_judgment", "")),
            narrative_logic=str(payload.get("narrative_logic", "")),
            structure=[],
            dimensions=[str(item) for item in payload.get("dimensions", [])],
            required_facts=[str(item) for item in payload.get("required_facts", [])],
            budget=payload.get("report_budget") if isinstance(payload.get("report_budget"), dict) else {},
            chapter_plans=[],
            user_requirements=user_requirements or "",
            plan_stage="analysis",
        )
        plan.analysis_plan_json = _plan_snapshot(plan, "analysis")
        return save_plan(plan)

    def finalize_report_plan(self, plan_id: int, context_block: str) -> ReportPlan:
        """Freeze the final report structure after Evidence + Analysis."""
        payload = self.generate_json(f"{context_block}\n\n请输出最终报告结构 JSON。", system=_FINAL_SYSTEM)
        chapters = payload.get("chapters") if isinstance(payload.get("chapters"), list) else []
        if not chapters:
            chapters = [{"title": "综合分析", "questions": [], "judgment": payload.get("core_judgment", "")}]
        plan = ReportPlan(
            id=plan_id,
            title=str(payload.get("title", "")),
            objective=str(payload.get("objective", "")),
            audience=str(payload.get("audience", "")),
            report_type=str(payload.get("report_type", "")),
            core_question=str(payload.get("core_question", "")),
            core_judgment=str(payload.get("core_judgment", "")),
            narrative_logic=str(payload.get("narrative_logic", "")),
            structure=[str(c.get("title", "")) for c in chapters if c.get("title")],
            dimensions=[],
            required_facts=[],
            budget=payload.get("report_budget") if isinstance(payload.get("report_budget"), dict) else {},
            chapter_plans=chapters,
            user_requirements="",
            plan_stage="final",
        )
        plan.final_plan_json = _plan_snapshot(plan, "final")
        return update_plan(plan)


def _plan_snapshot(plan: ReportPlan, stage: str) -> dict:
    return {
        "stage": stage,
        "title": plan.title,
        "objective": plan.objective,
        "audience": plan.audience,
        "report_type": plan.report_type,
        "core_question": plan.core_question,
        "core_judgment": plan.core_judgment,
        "narrative_logic": plan.narrative_logic,
        "structure": plan.structure,
        "dimensions": plan.dimensions,
        "required_facts": plan.required_facts,
        "chapter_plans": plan.chapter_plans,
        "budget": plan.budget,
        "user_requirements": plan.user_requirements,
    }


def save_plan(plan: ReportPlan) -> ReportPlan:
    with connect() as conn:
        cur = conn.execute(
            "INSERT INTO report_plans(title, objective, audience, report_type, core_question, "
            "core_judgment, narrative_logic, structure, dimensions, required_facts, chapter_plans, "
            "budget, user_requirements, plan_stage, plan_version, analysis_plan_json, final_plan_json) "
            "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (plan.title, plan.objective, plan.audience, plan.report_type,
             plan.core_question, plan.core_judgment, plan.narrative_logic,
             json.dumps(plan.structure, ensure_ascii=False),
             json.dumps(plan.dimensions, ensure_ascii=False),
             json.dumps(plan.required_facts, ensure_ascii=False),
             json.dumps(plan.chapter_plans, ensure_ascii=False),
             json.dumps(plan.budget, ensure_ascii=False),
             plan.user_requirements,
             plan.plan_stage,
             int(plan.plan_version or 1),
             json.dumps(plan.analysis_plan_json or _plan_snapshot(plan, "analysis"), ensure_ascii=False),
             json.dumps(plan.final_plan_json or {}, ensure_ascii=False)),
        )
        plan.id = cur.lastrowid
    return plan


def update_plan(plan: ReportPlan) -> ReportPlan:
    with connect() as conn:
        conn.execute(
            "UPDATE report_plans SET title=?, objective=?, audience=?, report_type=?, core_question=?, "
            "core_judgment=?, narrative_logic=?, structure=?, chapter_plans=?, budget=?, "
            "plan_stage='final', plan_version=plan_version + 1, final_plan_json=?, finalized_at=datetime('now') "
            "WHERE id=?",
            (
                plan.title, plan.objective, plan.audience, plan.report_type,
                plan.core_question, plan.core_judgment, plan.narrative_logic,
                json.dumps(plan.structure, ensure_ascii=False),
                json.dumps(plan.chapter_plans, ensure_ascii=False),
                json.dumps(plan.budget, ensure_ascii=False),
                json.dumps(plan.final_plan_json or _plan_snapshot(plan, "final"), ensure_ascii=False),
                plan.id,
            ),
        )
    return plan
